//
//  WinnerCollectionViewCell.swift
//  instaDemo
//
//  Created by apple on 24/02/17.
//  Copyright © 2017 OrangeApp. All rights reserved.
//

import UIKit

class NormalCell: UICollectionViewCell {

    @IBOutlet weak var usrImg: UIImageView!
    
    @IBOutlet weak var itemImg: UIImageView!
    
    @IBOutlet weak var lblcost: UILabel!
    
    
    @IBOutlet weak var lblTitle: UILabel!
    
    @IBOutlet weak var imgLike: UIImageView!
    
    
    @IBOutlet weak var lblPname: UILabel!
    
    
   
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
      
    }

}

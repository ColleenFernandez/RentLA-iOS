//
//  Category.m
//  CustomCellTest
//
//  Created by Punit Sindhwani on 7/16/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "CategoryMenu.h"

@implementation CategoryMenu

@synthesize name;
@synthesize imageName;
@synthesize list;
@synthesize listImg;
@synthesize controllerName;
@synthesize listController;
@end

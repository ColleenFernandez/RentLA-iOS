# iOS-HealthKit-Stats
A app that calculates some statistics based on your healthkit data from your iPhone or Apple Watch. Like total distance travelled.

<p align="center">
  <img height="500" src="./README-ASSETS/demo-pic-1.PNG">
  <img height="500" src="./README-ASSETS/demo-pic-7.PNG">  
</p>

## Screenshots
<p align="center">
  <img height="500" src="./README-ASSETS/demo-pic-1.PNG">
  <img height="500" src="./README-ASSETS/demo-pic-2.PNG">
  <img height="500" src="./README-ASSETS/demo-pic-3.PNG">
  <img height="500" src="./README-ASSETS/demo-pic-4.PNG">
</p>

<p align="center">
  <img height="500" src="./README-ASSETS/demo-pic-0.PNG">
  <img height="500" src="./README-ASSETS/demo-pic-5.PNG">
  <img height="500" src="./README-ASSETS/demo-pic-6.PNG">
  <img height="500" src="./README-ASSETS/demo-pic-7.PNG">  
</p>
